Maintainers
===========

**Active Maintainers**

| Name | GitHub | Chat | email
|------|--------|------|----------------------
| Alessandro Sorniotti | ale-linux | aso | <ale.linux@sopit.net>
| Artem Barger | c0rwin | c0rwin | <bartem@il.ibm.com>
| Binh Nguyen | binhn | binhn | <binh1010010110@gmail.com>
| Chris Ferris | christo4ferris | cbf | <chris.ferris@gmail.com>
| Dave Enyeart | denyeart | dave.enyeart | <enyeart@us.ibm.com>
| Gari Singh | mastersingh24 | mastersingh24 | <gari.r.singh@gmail.com>
| Jason Yellick | jyellick | jyellick | <jyellick@us.ibm.com>
| Jay Guo | guoger | guoger | <guojiannan1101@gmail.com>
| Jonathan Levi | hacera | JonathanLevi | <jonathan@hacera.com>
| Kostas Christidis | kchristidis | kostas | <kostas@gmail.com>
| Manish Sethi | manish-sethi | manish-sethi | <manish.sethi@gmail.com>
| Matthew Sykes | sykesm | sykesm | <sykesmat@us.ibm.com>
| Srinivasan Muralidharan | muralisrini | muralisr | <srinivasan.muralidharan99@gmail.com>
| Yacov Manevich | yacovm | yacovm | <yacovm@il.ibm.com>

**Documentation Maintainers**

| Name | GitHub | Chat | email
|------|--------|------|----------------------
| Anthony O'Dowd | odowdaibm  | odowdaibm | <a_o-dowd@uk.ibm.com>
| Chris Gabriel  | denali49   | cmgabriel | <alaskadd@gmail.com>
| Joe Alewine | joealewine | joe-alewine | <joe.alewine@ibm.com>
| Nikhil Gupta | nikhil550 | nikhilgupta | <negupta@us.ibm.com>
| Pam Andrejko | pamandrejko | pandrejko | <pama@ibm.com>

**Release Managers**

| Name | GitHub | Chat | email
|------|--------|------|----------------------
| Chris Ferris | christo4ferris | cbf | <chris.ferris@gmail.com>
| Dave Enyeart | denyeart | dave.enyeart | <enyeart@us.ibm.com>
| Gari Singh | mastersingh24 | mastersingh24 | <gari.r.singh@gmail.com>

**Retired Maintainers**

| Name | GitHub | Chat | email
|------|--------|------|----------------------
| Gabor Hosszu | gabre | hgabor | <gabor@digitalasset.com>
| Sheehan Anderson | srderson | sheehan | <sranderson@gmail.com>
| Tamas Blummer | tamasblummer | tamas | <tamas@digitalasset.com>
| Jim Zhang | jimthematrix | jimthematrix | <jim_the_matrix@hotmail.com>
| Yaoguo Jiang | jiangyaoguo | jiangyaoguo | <jiangyaoguo@gmail.com>
| Greg Haskins | ghaskins | ghaskins | <gregory.haskins@gmail.com>
| Keith Smith | smithbk | smithbk | <bksmith@us.ibm.com>
